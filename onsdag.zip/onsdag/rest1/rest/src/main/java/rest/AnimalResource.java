/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import entities.AnimalDTO;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author artin
 */
@Path("animal")
public class AnimalResource {
    @Context
    private UriInfo context;
    ArrayList<AnimalDTO> animals = new ArrayList<>();
    private static Gson gson = new GsonBuilder().setPrettyPrinting().create();

    @GET
    @Path("random")
    @Produces(MediaType.APPLICATION_JSON)
    public String getRandomAnimalDTOJson() {
// adds animals to a list
        animals.add(new AnimalDTO("Cat", 2004, "miaw"));
        animals.add(new AnimalDTO("cow", 2012, "moooooo"));
        animals.add(new AnimalDTO("Dog", 1999, "vovoovovo"));
        animals.add(new AnimalDTO("snake", 2017, "pisssssss"));
        Random random = new Random();

       
        AnimalDTO randoms = animals.get(random.nextInt(animals.size()));

        return new Gson().toJson(randoms);

    }

    

    /**
     * Creates a new instance of AnimalResource
     */
    public AnimalResource() {
    }

    /**
     * Retrieves representation of an instance of rest.AnimalResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    //@Produces(MediaType.APPLICATION_JSON)
    public String getJson() {

        // will post this when writting http://localhost:8080/rest/api/animal in url
        return "Hello from my first web service";
    }

    @GET
    @Path("dragon")
    @Produces(MediaType.APPLICATION_JSON)
    public String getDragon() {
        return "burn";

    }

    /**
     * PUT method for updating or creating an instance of AnimalResource
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void putJson(String content) {
    }
}
