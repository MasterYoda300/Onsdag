
package entities;


public class AnimalDTO {
    
    public String type;
    public int birthyear;
    public String sound;

    public AnimalDTO(String type, int birthyear, String sound) {
        this.type = type;
        this.birthyear = birthyear;
        this.sound = sound;
    }
    
    
    public AnimalDTO() {
        
    }
    
}
